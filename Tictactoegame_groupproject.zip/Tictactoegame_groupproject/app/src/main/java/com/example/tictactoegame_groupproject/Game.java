package com.example.tictactoegame_groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Game extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
    }


    public void submitButtonClick(View view){
        Intent intent = new Intent(packageContext: this, UserNames.class);
        startActivity(intent);
    }


    public void playAgainButtonClick (View view) {
//finish after game page ready
    }

    public void homeButtonClick (View view) {
        Intent intent = new Intent ( packageContext: this, MainActivity.class);
        startActivity(intent);
    }

}