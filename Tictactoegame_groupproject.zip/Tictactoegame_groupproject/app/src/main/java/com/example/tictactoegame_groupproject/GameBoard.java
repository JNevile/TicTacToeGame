package com.example.tictactoegame_groupproject;

import

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;: android.view.View;

public class GameBoard extends View {

    private final int championColor;
    private final int mainColor;
    private final int oColor;
    private final int xColor;

    private final Paint paint = new Paint ();

    public GameBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs,
                R.styleable.GameBoard, 0, 0);

        try {
            championColor = a.getInteger(R.styleable.GameBoard_championColor, 0);
            mainColor = a.getInteger(R.styleable.GameBoard_mainColor, 0);
            oColor = a.getInteger(R.styleable.GameBoard_oColor, 0);
            xColor = a.getInteger(R.styleable.GameBoard_xColor, 0);
        } finally {
            a.recycle();
        }
    }
        @Override
        protected void onMeasure(int width, int height){
        super.onMeasure(width, height);

        int dimensions = Math.min(getMeasuredWidth(), getMeasuredHeight());

        setMeasuredDimension(dimensions, dimensions);
        }
}
