package com.example.tictactoegame_groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserNames extends AppCompatActivity {

    private EditText player1;
    private EditText player2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_names);

        player1 = findViewById(R.id.player1Name);
        player2 = findViewById(R.id.player2Name);

    }

    public void submitButtonClick(View view){
        String player1Name = player1.getText() .toString();
        String player2Name = player2.getText() .toString();

        Intent intent = new Intent ( packageContext this, Game.class );
        Intent.putExtra( name: "PLAYER_NAMES", new String[] {player1Name, player2Name});
        startActivity(intent);

    }


}